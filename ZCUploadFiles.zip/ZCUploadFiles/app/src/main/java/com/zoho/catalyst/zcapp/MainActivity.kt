package com.zoho.catalyst.zcapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.zoho.catalyst.setup.ZCatalystApp
import com.zoho.catalyst.setup.ZCatalystSDKConfigs

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //TODO
        // 1
        // Replace app_configuration_development.properties with the properties file you downloaded
        // if not go to Catalyst Project -> Settings -> Developer Tools -> Android -> Register and Download your file
        // 2
        // Replace url_scheme value in res/strings.xml file
        // 3
        // Update your folder id in ZCSDKActions.uploadFile()
        // this app wont work without knowing where to upload
        // 4
        // For Login, go to Catalyst Project -> Authentication -> Add User


        // Initializing ZC SDK with the given configs
        // values from app_configuration_development.properties
        ZCatalystApp.init(applicationContext, ZCatalystSDKConfigs.AccountType.DEVELOPMENT)

        // Show Login Screen
        // App requires user to be logged In before accessing SDK operations
       ZCSDKActions(applicationContext).performLogin()

    }
}