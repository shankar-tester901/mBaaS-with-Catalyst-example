package com.zoho.catalyst.zcapp

import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.zoho.catalyst.exception.ZCatalystLogger
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.upload


// this activity uploads file from File Explore
class UploadActivity : AppCompatActivity() {

    private lateinit var getContent: ActivityResultLauncher<String>
    private var imageToUpload: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
        supportActionBar?.setTitle("Catalyst Demo")
        registerUploadEvent()

        // select image to perform upload
        // this launches the image picker and loads selected image in preview
        choose.setOnClickListener {
            getContent.launch("image/*")
        }

        // upload files to catalyst server
        // this handled the upload of selected image to the server
        upload.setOnClickListener {
            uploadImage()
        }

    }

    // methods that registers the activity result for the picker launch
    // and handles the preview with user selected image
    private fun registerUploadEvent()
    {
        getContent = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
                if ( uri != null )
                {
                    imageButton.setImageURI(uri)
                    imageToUpload = uri
                }
        }
    }

    // methods handles the operations that will
    // happen when user uploads the image
    private fun uploadImage() {
        imageToUpload?.let { it1 ->
            progressBar2.visibility = View.VISIBLE
            ZCSDKActions(applicationContext).uploadFile(it1,
                {
                    progressBar2.visibility = View.INVISIBLE
                    Toast.makeText(applicationContext, "File Uploaded Successfully.", Toast.LENGTH_LONG).show()
                },
                {
                    progressBar2.visibility = View.INVISIBLE
                    ZCatalystLogger.logInfo("upload Failed -> $it")
                    Toast.makeText(applicationContext, "File Upload Failed.", Toast.LENGTH_LONG).show()
                })
        }
    }

    // method to inflate the options menu when
    // the user opens the menu for the first time
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    // methods to control the operations that will
    // happen when user clicks on the action buttons
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.getItemId()) {
            R.id.logout ->
            {
                getContent.unregister()
                ZCSDKActions(applicationContext).performLogout()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}



