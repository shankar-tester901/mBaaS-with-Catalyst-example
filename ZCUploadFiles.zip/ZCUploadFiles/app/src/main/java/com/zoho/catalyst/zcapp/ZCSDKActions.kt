package com.zoho.catalyst.zcapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.zoho.catalyst.exception.ZCatalystException
import com.zoho.catalyst.exception.ZCatalystLogger
import com.zoho.catalyst.filestore.ZCatalystFile
import com.zoho.catalyst.setup.ZCatalystApp

class ZCSDKActions(val applicationContext: Context) {

    companion object
    {
        private val sdk = ZCatalystApp.getInstance()
    }

    // methods handles the login operations
    fun performLogin()
    {
        sdk.login(
            {

                ZCatalystLogger.logInfo("Login Success.")
                val mainActivityIntent = Intent(applicationContext, UploadActivity::class.java)
                mainActivityIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                ContextCompat.startActivity(applicationContext, mainActivityIntent, null)

            },
            {

                ZCatalystLogger.logError("login failed - $it")

            })
    }

    // methods handles the logout operations
    fun performLogout()
    {
        sdk.logout(
            {
                ZCatalystLogger.logInfo("Logout Success.")
                val mainActivityIntent =
                    Intent(applicationContext, MainActivity::class.java)
                mainActivityIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                ContextCompat.startActivity(applicationContext, mainActivityIntent, null)

            },
            {

                ZCatalystLogger.logError("Logout failed - $it")

            })
    }

    // methods handles the image upload to the catalyst server
    // 123456789 is the FOLDER_ID -> where you want to upload your image files
    fun uploadFile(uri: Uri, success: (ZCatalystFile) -> Unit, failure: (ZCatalystException) -> Unit)
    {
        sdk.getFileStoreInstance().getFolderInstance(123456789 ).uploadFile(
            uri,
            {
                success(it)
            },
            {
                ZCatalystLogger.logError("upload failed - $it")
                failure(it)
            })
    }
}